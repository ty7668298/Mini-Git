#include<iostream>
#include"miniGit.h"
using namespace std;

int main() {
	miniGit mG;
	while (mG.Menu());
	return 0;
}