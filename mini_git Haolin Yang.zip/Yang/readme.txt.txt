This program is a mini version control system, the system will prompt the user to initialize an empty repository in the current directory at the beginning. If the user choose "Yes". The menu screen will be displayed.
Option 1 is to ask the user to enter a file name and add the file to the repository.
Option 2 is to ask the user to enter a file name and remove the file from the repository.
Option 3 is for users to commit their changes to the file.
Option 4 allows the user to return to any previous version of the file by entering the version number.
Option 5 is used to exit the program.